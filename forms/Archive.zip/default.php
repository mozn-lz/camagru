<?php

$servername = "localhost";
$myDB = "camagru";
// $username = "admin";
// $password = "1234";
$username = "root";
$password = "wethinkcode";
$usrsTB = "users";

define ("SERVERNAME" , $servername);
define ("DBNAME" , $myDB);
define ("USERNAME" , $username);
define ("PASSWORD" , $password);
define ("SALT" , "whirlpool" );

?>